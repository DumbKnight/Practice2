# Тестовый сервер для практической работы 2, вариант 9
Для запуска скачать [Java 11](https://bell-sw.com/pages/downloads/) или выше

## Micronaut 2.3.3 Documentation

- [User Guide](https://docs.micronaut.io/2.3.3/guide/index.html)
- [API Reference](https://docs.micronaut.io/2.3.3/api/index.html)
- [Configuration Reference](https://docs.micronaut.io/2.3.3/guide/configurationreference.html)
- [Micronaut Guides](https://guides.micronaut.io/index.html)

---

## Feature tomcat-server documentation

- [Micronaut Tomcat Server documentation](https://micronaut-projects.github.io/micronaut-servlet/1.0.x/guide/index.html#tomcat)

## Feature http-client documentation

- [Micronaut HTTP Client documentation](https://docs.micronaut.io/latest/guide/index.html#httpClient)

